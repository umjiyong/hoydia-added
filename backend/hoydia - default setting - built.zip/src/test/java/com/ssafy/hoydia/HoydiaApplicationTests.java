package com.ssafy.hoydia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoydiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
